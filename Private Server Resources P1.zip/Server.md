
With Hamachi:

Name: CAATE Creative Private Server

Address: 25.129.222.121

Port: 2620
